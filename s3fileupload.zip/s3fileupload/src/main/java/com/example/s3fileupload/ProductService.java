package com.example.s3fileupload;

import java.io.IOException;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ProductService {
	
	private final ProductRepository productRepository;
	private final S3ImageService s3ImageService;
	
	public void saveProduct(Product product, MultipartFile file, String filePath) throws IOException {
	
		product.setImageUrl(s3ImageService.uploadImageToS3(file, filePath));
		productRepository.save(product);		
	}

	public Product getProduct(Long id) {
		return productRepository.findById(id).get();
	}

	public void updateProduct(Product product, MultipartFile file, String filePath) throws IOException {
		//s3 파일 삭제
		s3ImageService.deleteImage(getProduct(product.getId()).getImageUrl(), filePath);
		
		product.setImageUrl(s3ImageService.uploadImageToS3(file, filePath));
		productRepository.save(product);	
	}

}




