package com.example.s3fileupload;

import java.io.IOException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class ProductController {
	
	private final ProductService productService;
	
	@GetMapping("/productForm")
	public String add() {
		return "productForm";
	}
	
	@PostMapping("/productForm")
	public String add(@ModelAttribute("product") Product product, 
			@RequestParam("file") MultipartFile file) throws IOException {
		
		productService.saveProduct(product, file, "product/");
		
		return "productForm";
	}
	
	@GetMapping("/product/{id}")
	public String detail(@PathVariable("id") Long id, Model model) {
		Product product = productService.getProduct(id);
		model.addAttribute("product", product);
		
		return "productById";
	}
	
	@PostMapping("/productUpdate")
	public String update(@ModelAttribute("product") Product product, 
			@RequestParam("file") MultipartFile file, Model model) throws IOException {
		
		productService.updateProduct(product, file, "product/");
		model.addAttribute("message", "상품이 수정되었습니다.");
		
		return "productById";
	}
}















