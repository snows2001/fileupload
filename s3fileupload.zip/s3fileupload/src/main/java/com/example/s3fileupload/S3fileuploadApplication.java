package com.example.s3fileupload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S3fileuploadApplication {

	public static void main(String[] args) {
		SpringApplication.run(S3fileuploadApplication.class, args);
	}

}
