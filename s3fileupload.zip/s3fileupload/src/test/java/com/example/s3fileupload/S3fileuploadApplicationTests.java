package com.example.s3fileupload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S3fileuploadApplicationTests {

	@Test
	void contextLoads() {
	}

}
