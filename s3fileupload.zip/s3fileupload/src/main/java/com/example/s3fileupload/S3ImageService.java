package com.example.s3fileupload;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;

import lombok.RequiredArgsConstructor;


@Component
@RequiredArgsConstructor
public class S3ImageService {
	
	private final AmazonS3 amazonS3;
	
	@Value("${cloud.aws.s3.bucketName}")
	private String bucketName;
	
	public String uploadImageToS3(MultipartFile file, String filePath) throws IOException {
		//s3 저장 코드
		
		//원본 파일명
		String originalFileName = file.getOriginalFilename();	
		//s3 에 저장할 변경된 파일명
		String s3FileName = filePath + UUID.randomUUID().toString().substring(0, 10) + originalFileName;
		//확장자 명
		String extention = originalFileName.substring(originalFileName.lastIndexOf(".") + 1);
		
		
		//파일 읽어오기
		InputStream is = file.getInputStream();
		
		//메타정보
		ObjectMetadata metadata = new ObjectMetadata();
		metadata.setContentType("image/" + extention);
		metadata.setContentLength(file.getBytes().length);
		
		PutObjectRequest putObjectRequest 
			= new PutObjectRequest(bucketName, s3FileName, is, metadata)
			  .withCannedAcl(CannedAccessControlList.PublicRead);
		
		amazonS3.putObject(putObjectRequest);
		
		is.close();
		
		return URLDecoder.decode(amazonS3.getUrl(bucketName, s3FileName).toString(), 
				StandardCharsets.UTF_8);
	} 
	//https://bucket-gfzji3.s3.ap-northeast-2.amazonaws.com/product/5a398d43-5image.png
	public void deleteImage(String imageUrl, String filePath) {
		amazonS3.deleteObject(bucketName, 
				filePath + imageUrl.substring(imageUrl.lastIndexOf("/") + 1));
	}
}










